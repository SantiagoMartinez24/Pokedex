# React + TypeScript + Vite
POKEDEX - Explorador de Pokémon

Este es un proyecto de Pokédex interactiva desarrollado en React con TypeScript.  
Los datos se obtienen desde la PokéAPI utilizando GraphQL.

---

Instrucciones para ejecutar el proyecto

1. Descargar el repositorio

Abre una terminal y ejecuta:

git clone https://github.com/tu-usuario/pokedex.git
cd pokedex

2. Iniciar el servidor de desarrollo

Inicia la aplicación con:

npm run dev

Una vez iniciado, abre tu navegador y visita:

http://localhost:4001

---

Estructura del código

- src/graphql/queries.ts: contiene las consultas a la API GraphQL.
- src/pages: contiene las pantallas principales de la aplicación.
- src/router.tsx: configuración de rutas con React Router.

---

Requisitos

- Node.js y npm instalados.
- Conexión a internet para consumir la API pública.

---

Autor

420
Segundo corte – Programación Avanzada  
Universidad Jorge Tadeo Lozano  
2025

import { useQuery } from "@apollo/client";
import { GET_POKEMONS } from "../graphql/queries";
import { Link } from "react-router-dom";
import "../styles/styles.css"; 

const PokemonList = () => {
  const { loading, error, data } = useQuery(GET_POKEMONS);

  if (loading) return <p className="loading">Cargando Pokémon...</p>;
  if (error) return <p className="error">Error al cargar los datos.</p>;

  return (
    <div className="container">
      <h1 className="title">Pokédex</h1>
      <div className="pokemon-grid">
        {data.pokemons.results.map((pokemon: any) => (
          <Link to={`/pokemon/${pokemon.id}`} key={pokemon.id} className="pokemon-card">
            <img src={pokemon.image} alt={pokemon.name} className="pokemon-image" />
            <div className="pokemon-info">
              <p className="pokemon-id">#{pokemon.id}</p>
              <h2 className="pokemon-name">{pokemon.name}</h2>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default PokemonList;

import { useQuery } from "@apollo/client";
import { GET_POKEMON_DETAIL } from "../graphql/queries";
import { useParams, Link } from "react-router-dom";

// Definimos interfaces para tipar los datos correctamente
interface PokemonType {
  pokemon_v2_type: {
    name: string;
  };
}

interface PokemonAbility {
  pokemon_v2_ability: {
    name: string;
  };
}

interface PokemonStat {
  pokemon_v2_stat: {
    name: string;
  };
  base_stat: number;
}

const statTranslations: Record<string, string> = {
  hp: "Puntos de Salud",
  attack: "Ataque",
  defense: "Defensa",
  "special-attack": "Ataque Especial",
  "special-defense": "Defensa Especial",
  speed: "Velocidad",
};

const PokemonDetail = () => {
  const { id } = useParams();
  const { loading, error, data } = useQuery(GET_POKEMON_DETAIL, { variables: { id: Number(id) } });

  if (loading) return <p className="loading">Cargando...</p>;
  if (error) return <p className="error-message">Error al cargar datos. Inténtalo nuevamente.</p>;

  const pokemon = data.pokemon_v2_pokemon[0];
  const sprites = pokemon.pokemon_v2_pokemonsprites[0]?.sprites || {};
  const imageUrl = sprites?.other?.["official-artwork"]?.front_default || sprites?.front_default || "/placeholder.png";

  return (
    <div className="pokemon-detail">
      <div className="pokemon-detail-container">
        <div className="pokemon-image-container">
          <img src={imageUrl} alt={pokemon.name} className="pokemon-image" />
        </div>

        <div className="pokemon-info">
          <h1 className="pokemon-name">#{pokemon.id} {pokemon.name}</h1>

          <p><strong>Altura:</strong> {pokemon.height} m</p>
          <p><strong>Peso:</strong> {pokemon.weight} kg</p>
          <p>
            <strong>Tipos:</strong>{" "}
            {pokemon.pokemon_v2_pokemontypes.map((t: PokemonType) => t.pokemon_v2_type.name).join(", ")}
          </p>
          <p>
            <strong>Habilidades:</strong>{" "}
            {pokemon.pokemon_v2_pokemonabilities.map((a: PokemonAbility) => a.pokemon_v2_ability.name).join(", ")}
          </p>

          <p><strong>Estadísticas de Combate:</strong></p>
          <ul>
            {pokemon.pokemon_v2_pokemonstats.map((stat: PokemonStat) => (
              <li key={stat.pokemon_v2_stat.name}>
                <strong>{statTranslations[stat.pokemon_v2_stat.name] || stat.pokemon_v2_stat.name}:</strong> {stat.base_stat}
              </li>
            ))}
          </ul>

          <Link to="/" className="back-button">Volver al Inicio</Link>
        </div>
      </div>
    </div>
  );
};

export default PokemonDetail;

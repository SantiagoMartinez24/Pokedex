import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@apollo/client";
import { GET_POKEMONS } from "../graphql/queries";
import "../styles/styles.css";
import pokemonLogo from "../imagenes/pokemon-logo.png"; 


interface Pokemon {
  id: number;
  name: string;
  image: string;
  types: string[];
  weight: number;
  height: number;
}


interface GraphQLPokemon {
  id: number;
  name: string;
  weight: number;
  height: number;
  pokemon_v2_pokemonsprites: { sprites: any }[];
  pokemon_v2_pokemontypes: { pokemon_v2_type: { name: string } }[];
}

const Home: React.FC = () => {
  const { loading, error, data } = useQuery(GET_POKEMONS, { variables: { limit: 50 } });

  
  const [typeFilter, setTypeFilter] = useState<string>("");
  const [weightFilter, setWeightFilter] = useState<string>("");
  const [heightFilter, setHeightFilter] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState<string>("");

  if (loading) return <p className="loading">Cargando...</p>;
  if (error) return <p className="error-message">Error al cargar datos.</p>;

  
  let pokemons: Pokemon[] = data.pokemon_v2_pokemon.map((pokemon: GraphQLPokemon) => {
    let imageUrl = "/placeholder.png"; 
    try {
      const sprites = pokemon.pokemon_v2_pokemonsprites?.[0]?.sprites;
      if (sprites) {
        imageUrl =
          sprites.other?.["official-artwork"]?.front_default ||
          sprites.front_default ||
          sprites.other?.home?.front_default ||
          "/placeholder.png";
      }
    } catch (error) {
      console.error(`Error al obtener la imagen de ${pokemon.name}:`, error);
    }

    return {
      id: pokemon.id,
      name: pokemon.name,
      image: imageUrl,
      types: pokemon.pokemon_v2_pokemontypes.map((t) => t.pokemon_v2_type.name),
      weight: pokemon.weight,
      height: pokemon.height,
    };
  });

  
  if (searchTerm) {
    pokemons = pokemons.filter(
      (p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.id.toString() === searchTerm
    );
  }

  if (typeFilter) {
    pokemons = pokemons.filter((p) => p.types.includes(typeFilter));
  }

  if (weightFilter === "min") {
    pokemons = [pokemons.reduce((prev, curr) => (prev.weight < curr.weight ? prev : curr))];
  } else if (weightFilter === "max") {
    pokemons = [pokemons.reduce((prev, curr) => (prev.weight > curr.weight ? prev : curr))];
  }

  if (heightFilter === "min") {
    pokemons = [pokemons.reduce((prev, curr) => (prev.height < curr.height ? prev : curr))];
  } else if (heightFilter === "max") {
    pokemons = [pokemons.reduce((prev, curr) => (prev.height > curr.height ? prev : curr))];
  }

  return (
    <div className="relative">
      {/* Línea roja con logo */}
      <div className="red-line">
        <img src={pokemonLogo} alt="Pokemon Logo" className="pokemon-logo" />
      </div>

      {/* Descripción de la Pokédex */}
      <p className="pokedex-description">
        La Pokédex es una página donde encontraremos una lista de 50 Pokémon disponibles, en la que podremos ver desde sus características básicas, como tamaño y peso, hasta sus habilidades y tipo de Pokémon.
      </p>

      {/* Contenido principal */}
      <div className="text-center mt-8">
        <h1 className="text-3xl font-bold">Lista de Pokémon</h1>

        {/* Barra de búsqueda */}
        <input
          type="text"
          placeholder="Buscar Pokémon..."
          className="search-bar"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        {/* Filtros */}
        <div className="filters">
          <select className="filter-button" onChange={(e) => setTypeFilter(e.target.value)}>
            <option value="">Tipos</option>
            <option value="water">Agua</option>
            <option value="fire">Fuego</option>
            <option value="grass">Planta</option>
            <option value="electric">Eléctrico</option>
          </select>

          <select className="filter-button" onChange={(e) => setWeightFilter(e.target.value)}>
            <option value="">Peso</option>
            <option value="min">Peso Mínimo</option>
            <option value="max">Peso Máximo</option>
          </select>

          <select className="filter-button" onChange={(e) => setHeightFilter(e.target.value)}>
            <option value="">Altura</option>
            <option value="min">Altura Mínima</option>
            <option value="max">Altura Máxima</option>
          </select>
        </div>

        {/* Lista de Pokémon */}
        <div className="pokemon-container">
          {pokemons.map((pokemon) => (
            <div key={pokemon.id} className="pokemon-card">
              <Link to={`/pokemon/${pokemon.id}`} className="pokemon-link">
                <img src={pokemon.image} alt={pokemon.name} className="pokemon-image" />
                <div className="pokemon-info">
                  <span className="pokemon-id">#{pokemon.id}</span>
                  <h3 className="pokemon-name">{pokemon.name}</h3>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
